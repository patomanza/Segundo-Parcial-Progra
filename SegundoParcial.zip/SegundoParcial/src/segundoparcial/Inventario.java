package segundoparcial;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;


public class Inventario<T extends CSVSerializable & Comparable<T>> {
    private List<T> libros;
    
    public Inventario(){
        this.libros = new ArrayList<>();
    }
    
    public void agregarLibro(T libro){
        libros.add(libro);
    }
    
    public T obtenerIndice(int indice){
        return libros.get(indice);
    }
    
    public void eliminarLibro(int indice){
        libros.remove(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T libro : libros) {
            if (criterio.test(libro)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }
    
     public void ordenar() {
        libros.sort(null); // Orden natural (Comparable)
    }

    public void ordenar(Comparator<T> comparador) {
        libros.sort(comparador);
    }
    
    public void guardarLibrosCSV(String path) throws IOException{
        File archivo = new File(path);
        
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe.");
            }else {
            archivo.createNewFile();
            }
        } 
        catch (IOException ex) {
        System.out.println("Ocurrió un error al crear el archivo: " + ex.getMessage());
        return;
        }
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("ID,Titulo,Autor,Categoria\n");
            
            for(T libro : libros)
            {
                bw.write(libro.toCSV() + "\n");
                bw.newLine();
                
            }
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
     public static List<Libro> cargarLibrosDesdeCSV(String path) throws IOException {
        List<Libro> toReturn = new ArrayList<>();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = bf.readLine()) != null) {
                
                String[] data = linea.split(",");
               
                if (data.length == 4) {
                    
                    int id = Integer.parseInt(data[0]);
                    String titulo = data[1];
                    String autor = data[2];
                    Categoria categoria = Categoria.valueOf(data[3].toUpperCase());

                    Libro libro = new Libro(id, titulo, autor, categoria);
                    toReturn.add(libro);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Problema al cargar libros desde CSV", ex);
        }
        return toReturn;
     }

     public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        libros.forEach(accion);
    }

    @FunctionalInterface
    public interface FromCSV<T> {
        T convert(String csv);
    }
}

