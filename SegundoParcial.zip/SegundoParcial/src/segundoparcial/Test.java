package segundoparcial;
/*
PARCIAL INCOMPLETO!
*/

import java.io.IOException;
import java.util.Comparator;

public class Test {
    public static void main(String[] args) {
        try {
            
            Inventario<Libro> inventario = new Inventario<>();
            
            inventario.agregarLibro(new Libro(1, "1984", "George Orwell", Categoria.ENTRETENIMIENTO));
            inventario.agregarLibro(new Libro(2, "El señor de los anillos", "J.R.R. Tolkien", Categoria.LITERATURA));

            System.out.println("Todos los libros:");
            inventario.paraCadaElemento(System.out::println);

            System.out.println("\nFiltrar por categoría LITERATURA:");
            inventario.filtrar(libro -> libro.getCategoria() == Categoria.LITERATURA)
                    .forEach(System.out::println);

            System.out.println("\nOrdenar por título:");
            inventario.ordenar(Comparator.comparing(Libro::getTitulo));
            inventario.paraCadaElemento(System.out::println);
            
            inventario.guardarLibrosCSV("src/data/libros.csv");
            


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
