package segundoparcial;


public enum Categoria {
    CIENCIA,
    LITERATURA,
    TECNOLOGIA,
    ARTE,
    HISTORIA,
    ENTRETENIMIENTO;

}
